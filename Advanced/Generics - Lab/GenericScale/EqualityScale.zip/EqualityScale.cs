﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericScale
{
    public class EqualityScale<T>
    {
        public EqualityScale(T left, T right)
        {

        }

        public T Left { get; }
        public T Right { get; }
        public  bool AreEqual()
        {
            return this.Left.Equals(this.Right);
        }
    }
}
