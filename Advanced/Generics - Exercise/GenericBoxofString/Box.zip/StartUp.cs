﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

namespace GenericBoxofString
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            var list = new List<double>();
            for (int i = 0; i < n; i++)
            {
                var input = double.Parse(Console.ReadLine());
                list.Add(input);
            }

            var box = new Box<double>(list);
            var element = double.Parse(Console.ReadLine());
            Console.WriteLine(box.Counter(box.Values, element));
            //var indexes = Console.ReadLine().Split().Select(int.Parse).ToArray();
            //var firstIndex = indexes[0];
            //var secondIndex = indexes[1];
            //box.Swap(list, firstIndex, secondIndex);
            //Console.WriteLine(box);
        }
    }
}
