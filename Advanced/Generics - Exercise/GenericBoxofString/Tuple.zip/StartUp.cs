﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

namespace GenericBoxofString
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //var n = int.Parse(Console.ReadLine());
            //var list = new List<double>();
            //for (int i = 0; i < n; i++)
            //{
            //    var input = double.Parse(Console.ReadLine());
            //    list.Add(input);
            //}

            //var box = new Box<double>(list);
            //var element = double.Parse(Console.ReadLine());
            //Console.WriteLine(box.Counter(box.Values, element));
            //var indexes = Console.ReadLine().Split().Select(int.Parse).ToArray();
            //var firstIndex = indexes[0];
            //var secondIndex = indexes[1];
            //box.Swap(list, firstIndex, secondIndex);
            //Console.WriteLine(box);

            var firstInput = Console.ReadLine()
                .Split()
                .ToArray();
            var name = $"{firstInput[0]} {firstInput[1]}";
            var address = firstInput[2];
            Tuple<string, string> firstTuple = new Tuple<string, string>(name, address);

            var secondInput = Console.ReadLine()
                .Split()
                .ToArray();
            var person = secondInput[0];
            var amountBeer = int.Parse(secondInput[1]);
            Tuple<string, int> secondTuple = new Tuple<string, int>(person, amountBeer);

            var thirdInput = Console.ReadLine()
                .Split()
                .ToArray();
            var firstArg = int.Parse(thirdInput[0]);
            var secondArg = double.Parse(thirdInput[1]);
            Tuple<int, double> thirdTuple = new Tuple<int, double>(firstArg,secondArg);

            Console.WriteLine(firstTuple);
            Console.WriteLine(secondTuple);
            Console.WriteLine(thirdTuple);



        }
    }
}
