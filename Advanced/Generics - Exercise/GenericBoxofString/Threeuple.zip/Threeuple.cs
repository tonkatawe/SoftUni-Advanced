﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericBoxofString
{
    public class Threeuple<T, K, M>
    {
        public Threeuple(T firstItem, K secondItem, M thirdItem)
        {
            this.First = firstItem;
            this.Second = secondItem;
            this.Third = thirdItem;
        }
        public T First { get; set; }
        public K Second { get; set; }
        public M Third { get; set; }
        public override string ToString()
        {
            return $"{this.First} -> {this.Second} -> {this.Third}";
        }
    }
}
