﻿
using System;
using System.Linq;
using System.Reflection;
using System.Text;

public class Spy
{
    public string StealFieldInfo(string investigatedClass, params string[] requestedFields)
    {
        Type classType = Type.GetType($"{investigatedClass}");
        FieldInfo[] classFields = classType.GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public |
                                                      BindingFlags.Static);
        var result = new StringBuilder();

        Object classInstance = Activator.CreateInstance(classType, new object[] { });

        result.AppendLine($"Class under investigation: {investigatedClass}");

        foreach (var field in classFields.Where(f => requestedFields.Contains(f.Name)))
        {
            result.AppendLine($"{field.Name} == {field.GetValue(classInstance)}");
        }
        return result.ToString().TrimEnd();
    }
}

