﻿

namespace WildFarm.Contracts
{
    interface IEngine
    {
        
        void Run();
    }
}
