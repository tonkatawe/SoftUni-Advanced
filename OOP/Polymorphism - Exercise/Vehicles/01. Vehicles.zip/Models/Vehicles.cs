﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;

namespace Vehicles.Models
{
    public abstract class Vehicles
    {
        
        public Vehicles(double fuelQuantity, double fuelConsumption)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsumption;
        }
        public double FuelQuantity { get; protected set; }
        protected double FuelConsumption { get; set; }

        public virtual string Drive(double distance)
        {
            var result = string.Empty;

            return $"{this.GetType().Name} travelled  {distance} km";
        }

        public virtual double Refuel(double fuelAmount)
        {
            return this.FuelQuantity += fuelAmount;
        }
    }
}
