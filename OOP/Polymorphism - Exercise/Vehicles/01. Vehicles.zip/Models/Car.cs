﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Vehicles.Models
{
    public class Car : Vehicles
    {
        private const double airConditionNeeds = 0.9;

        public Car(double fuelQuantity, double fuelConsumption)
            : base(fuelQuantity, fuelConsumption)
        {
            this.FuelConsumption += airConditionNeeds;
        }

        public override string Drive(double distance)
        {
            var neededFuel = distance * this.FuelConsumption;
            if (neededFuel > FuelQuantity)
            {
                return "Car needs refueling";
            }

            this.FuelQuantity -= neededFuel;
            return $"Car travelled {distance} km";
        }

        public override double Refuel(double fuelAmount)
        {
            return base.Refuel(fuelAmount);
        }
    }
}
