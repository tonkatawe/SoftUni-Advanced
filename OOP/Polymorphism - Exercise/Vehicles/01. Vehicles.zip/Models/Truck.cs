﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Models
{
    public class Truck : Vehicles
    {
        private const double airConditionNeeds = 1.6;

        public Truck(double fuelQuantity, double fuelConsumption)
            : base(fuelQuantity, fuelConsumption)
        {
            this.FuelConsumption += airConditionNeeds;
        }

        public override string Drive(double distance)
        {
            var neededFuel = distance * this.FuelConsumption;
            if (neededFuel > FuelQuantity)
            {
                return "Truck needs refueling";
            }

            this.FuelQuantity -= neededFuel;
            return $"Truck travelled {distance} km";
        }

        public override double Refuel(double fuelAmount)
        {
            fuelAmount *= 0.95;
            return base.Refuel(fuelAmount);
        }
    }
}
