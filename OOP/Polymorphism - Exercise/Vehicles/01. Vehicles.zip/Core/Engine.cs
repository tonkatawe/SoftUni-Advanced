﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using Vehicles.Models;

namespace Vehicles.Core
{
    public class Engine
    {
        public void Run()
        {
            var readCar = Console.ReadLine().Split();
            var car = new Car(double.Parse(readCar[1]), double.Parse(readCar[2]));
            var readTruck = Console.ReadLine().Split();
            var truck = new Truck(double.Parse(readTruck[1]), double.Parse(readTruck[2]));
            var n = int.Parse(Console.ReadLine()); //read number of commands
            for (int i = 0; i < n; i++)
            {
                var input = Console.ReadLine()
                    .Split()
                    .ToArray();
                var command = input[0];
                var vehicleType = input[1];
                var value = double.Parse(input[2]);
                if (command == "Drive")
                {
                    if (vehicleType == "Car")
                    {
                        Console.WriteLine(car.Drive(value));

                    }
                    else if (vehicleType == "Truck")
                    {
                        Console.WriteLine(truck.Drive(value));
                    }
                }
                else if (command == "Refuel")
                {
                    if (vehicleType == "Car")
                    {
                        car.Refuel(value);
                    }
                    else if (vehicleType == "Truck")
                    {
                        truck.Refuel(value);
                    }
                }
            }

            Console.WriteLine($"Car: {car.FuelQuantity:F2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:F2}");
        }
    }
}
