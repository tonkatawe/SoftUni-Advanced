﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CollectionHierarchy.Interfaces
{
    public interface IAddRemoveCollection
    {
        string[] Remove(string[] input, int n);

    }
}
