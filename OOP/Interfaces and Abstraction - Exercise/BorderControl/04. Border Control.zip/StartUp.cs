﻿using System;
using System.Collections.Generic;
using BorderControl;

namespace Bo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var inhabitants = new List<IIdentifiable>();
            while (true)
            {
                var input = Console.ReadLine();
                if (input == "End")
                {
                    break;
                }

                var tokens = input.Split();
                if (tokens.Length == 2)
                {
                    var model = tokens[0];
                    var id = tokens[1];
                    var currentRobot = new Robot(model, id);
                    inhabitants.Add(currentRobot);
                }
                else if (tokens.Length == 3)
                {
                    var name = tokens[0];
                    var age = int.Parse(tokens[1]);
                    var id = tokens[2];
                    var currentCitizen = new Citizen(name, age, id);
                    inhabitants.Add(currentCitizen);
                }
            }

            var fakeId = Console.ReadLine();
            inhabitants.FindAll(x => x.Id.EndsWith(fakeId))
                .ForEach(y => Console.WriteLine(y.Id));
        }
    }
}
