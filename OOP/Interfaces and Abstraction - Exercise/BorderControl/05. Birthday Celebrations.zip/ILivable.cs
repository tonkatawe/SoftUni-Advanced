﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface ILivable
    {
        string Name { get; }
        string Birthday { get; }
    }
}
