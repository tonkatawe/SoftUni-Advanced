﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _4._Hotel_Reservation
{
    public enum Discount
    {
        None,
        SecondVisit = 10,
        VIP = 20
    }

}
